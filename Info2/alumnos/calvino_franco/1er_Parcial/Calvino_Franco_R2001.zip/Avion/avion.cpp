#include "avion.h"

ostream& operator<< (ostream& out, const Avion& a)
{
    out << ">> Matricula: " << a.Matricula << "\tCia: " << a.Cia << "\n";

    return out;
}
