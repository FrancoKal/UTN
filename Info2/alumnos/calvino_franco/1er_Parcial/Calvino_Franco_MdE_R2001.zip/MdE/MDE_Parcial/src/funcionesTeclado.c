#include "../MyIncludes/funcionesTeclado.h"

uint8_t TECLADO_Leer (void)
{
    uint8_t resultado;

    return resultado;
}