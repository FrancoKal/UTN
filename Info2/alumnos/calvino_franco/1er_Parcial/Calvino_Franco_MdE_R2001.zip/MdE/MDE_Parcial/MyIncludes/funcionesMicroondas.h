#ifndef FUNCIONES_MICROONDAS_H
#define FUNCIONES_MICROONDAS_H

#include "funcionesBiblioteca.h"

void UART_Enviar (uint8_t estado);

#endif