#ifndef MDE_MICROONDAS_H
#define MDE_MICROONDAS_H

enum estadosMicroondas {REPOSO = 0, ENCENDIDO = 1};

void MDE_Microondas (void);

#endif
