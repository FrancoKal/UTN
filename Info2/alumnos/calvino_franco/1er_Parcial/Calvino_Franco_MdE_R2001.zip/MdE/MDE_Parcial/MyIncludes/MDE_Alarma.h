#ifndef MDE_ALARMA_H
#define MDE_ALARMA_H

enum estadosAlarma {REPOSO = 0, ENCENDIDA = 1, APAGADA = 2};

void MDE_Alarma (void);

#endif
