#ifndef MDE_TERMOSTATO_H
#define MDE_TERMOSTATO_H

enum estadosTermostato {REPOSO = 0, ESPERANDO_ENCENDIDO = 1, ENCENDIDO = 2};

void MDE_Termostato (void);

#endif
