#ifndef MDE_TECLADO_H
#define MDE_TECLADO_H

enum estadosTeclado {REPOSO = 0, RECIBIENDO = 1};

void MDE_Teclado (void);

#endif
