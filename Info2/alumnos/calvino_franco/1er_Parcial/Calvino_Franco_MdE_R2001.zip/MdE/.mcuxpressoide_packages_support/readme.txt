This folder is automatically created and contains the SDK part support for the IDE
*** DO NOT REMOVE OR MODIFY, YOUR CHANGES WILL BE OVERWRITTEN ON SDK REFRESH ***